from flask import Flask, request, jsonify
import speech_recognition as sr
from flask_cors import CORS  # Import CORS
from io import BytesIO

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Sample list of languages and their codes
LANGUAGES = [
    {"code": "en-UK", "name": "English (UK)"},
    {"code": "en-US", "name": "English (US)"},
    {"code": "fr-FR", "name": "French (France)"},
    {"code": "te-IN", "name": "Telugu"},
    {"code": "kn-IN", "name": "Kannada"},
    {"code": "de-DE", "name": "German (Germany)"},
    {"code": "sn-ZW", "name": "Shona (Zimbabwe)"},
    
    # Add more languages as needed
]

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint to confirm the backend is running."""
    return jsonify({"status": "healthy"}), 200

@app.route('/languages', methods=['GET'])
def get_languages():
    return jsonify({"languages": LANGUAGES})

@app.route('/speech-to-text', methods=['POST'])
def speech_to_text():
    if 'audio' not in request.files:
        return jsonify({"error": "No audio file provided"}), 400

    # Get the uploaded audio file
    audio_file = request.files['audio']
    
    # Use BytesIO to read the file in memory without saving it
    audio_data = BytesIO(audio_file.read())
    
    recognizer = sr.Recognizer()

    try:
        # Perform speech recognition using PocketSphinx directly on the in-memory file
        with sr.AudioFile(audio_data) as source:
            audio_content = recognizer.record(source)
            text = recognizer.recognize_sphinx(audio_content)

        return jsonify({"text": text})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
