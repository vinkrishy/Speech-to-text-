import React from 'react';
import './App.css';
import SpeechToText from './speech-to-text/SpeechToText';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function App() {
  return (
    <div className="App">
      <ToastContainer />
      <SpeechToText />
    </div>
  );
}

export default App;
