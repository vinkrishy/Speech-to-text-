import React, { useState, useEffect, useRef } from 'react';
import { BsFillMicFill } from 'react-icons/bs';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import { toast } from 'react-toastify';
import {
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  Card,
  CardContent,
  Grid,
} from '@mui/material';

const SpeechToText = () => {
  const [transcript, setTranscript] = useState('');
  const [copied, setCopied] = useState(false);
  const [languages, setLanguages] = useState([]);
  const [selectedLanguage, setSelectedLanguage] = useState('en-UK');
  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState(null);
  const [audioChunks, setAudioChunks] = useState([]);
  const [audioUrl, setAudioUrl] = useState(null);
  const recognitionRef = useRef(null);
  const timerRef = useRef(null);
  const audioRef = useRef(null);
  const idleTimerRef = useRef(null); // Timer for idle detection

  useEffect(() => {
    const fetchLanguages = async () => {
      try {
        const response = await fetch('http://127.0.0.1:5000/languages'); // Fetch languages from the backend
        if (!response.ok) {
          throw new Error('Failed to fetch languages');
        }
        const languagesResponse = await response.json();
        setLanguages(languagesResponse.languages);
      } catch (error) {
        toast.error('Error fetching languages: ' + error.message);
      }
    };

    fetchLanguages();
  }, []);

  const checkBackend = async () => {
    try {
      const response = await fetch('http://127.0.0.1:5000/health', {
        method: 'GET',
      });
      return response.ok; // Return true if the response is OK
    } catch (error) {
      return false; // Return false if there was an error
    }
  };

  const startRecording = async () => {
    // Check if the backend is running before starting recording
    const isBackendRunning = await checkBackend();
    if (!isBackendRunning) {
      toast.error('Backend server is not running. Please start the server and try again.');
      return; // Do not proceed if the backend is not running
    }

    if (!('webkitSpeechRecognition' in window)) {
      toast.error('Speech recognition not supported in this browser.');
      return;
    }

    navigator.mediaDevices.getUserMedia({ audio: true }).then((stream) => {
      const mediaRecorder = new MediaRecorder(stream);
      setMediaRecorder(mediaRecorder);

      mediaRecorder.ondataavailable = (event) => {
        setAudioChunks((prev) => [...prev, event.data]);
      };

      mediaRecorder.start();
      setIsRecording(true); // Set recording state to true
      toast.info('Recording started...'); // Notify user that recording has started

      // Automatically stop recording after a specified time (optional)
      timerRef.current = setTimeout(stopRecording, 30000); // Auto stop after 30 seconds

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
        sendAudioToBackend(audioBlob); // Send the audio data to the backend
      };
    }).catch((error) => {
      toast.error('Error accessing microphone. Please check your permissions.');
    });

    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }

    const recognition = new window.webkitSpeechRecognition();
    recognition.lang = selectedLanguage;
    recognition.continuous = true;
    recognition.interimResults = true;
    recognitionRef.current = recognition;

    recognition.onresult = (event) => {
      let interimTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          setTranscript((prev) => prev + event.results[i][0].transcript + '. ');
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }
      resetIdleTimer(); // Reset idle timer on speech recognition
    };

    recognition.onerror = (event) => {
      toast.error('Speech recognition error occurred: ' + event.error);
    };

    recognition.onend = () => {
      setIsRecording(false);
      toast.info('Speech recognition stopped.');
    };

    recognition.start();
    startIdleTimer(); // Start the idle timer when recording starts
  };

  const stopRecording = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    if (mediaRecorder) {
      mediaRecorder.stop();
      setIsRecording(false); // Update state to reflect that recording has stopped
      toast.info('Recording stopped.');
    }
    clearTimeout(timerRef.current); // Clear any running timer
    clearTimeout(idleTimerRef.current); // Clear idle timer when recording stops
  };

  const sendAudioToBackend = async (audioBlob) => {
    try {
      const formData = new FormData();
      formData.append('audio', audioBlob, 'audio.wav'); // Append the audio blob to form data

      const response = await fetch('http://127.0.0.1:5000/speech-to-text', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        // throw new Error('Failed to process audio on the server.');
      }

      const result = await response.json();
      if (result.text) {
        setTranscript(result.text); // Set the transcript from the API response
      } else {
        toast.error('No text returned from the server.');
      }
    } catch (error) {
      toast.error('Error processing audio: ' + error.message);
    }
  };

  const handleDownload = () => {
    if (audioUrl) {
      const a = document.createElement('a');
      a.href = audioUrl;
      a.download = 'processed_audio.wav'; // Name of the downloaded file
      a.click();
      URL.revokeObjectURL(audioUrl);
      toast.success('Audio file downloaded successfully.');
    } else {
      toast.error('No audio file available to download.');
    }
  };

  const handleCopy = () => {
    setCopied(true);
    navigator.clipboard.writeText(transcript);
    toast.success('Text copied to clipboard!');
    setTimeout(() => {
      setCopied(false);
    }, 1500);
  };

  const clearText = () => {
    setTranscript('');
    toast.info('Transcript cleared.');
  };

  const handleLanguageChange = (e) => {
    setSelectedLanguage(e.target.value);
  };

  // Start the idle timer
  const startIdleTimer = () => {
    idleTimerRef.current = setTimeout(() => {
      stopRecording(); // Stop recording if the user is idle for 3 seconds
    }, 3000); // 3000 milliseconds = 3 seconds
  };

  // Reset the idle timer
  const resetIdleTimer = () => {
    clearTimeout(idleTimerRef.current); // Clear the current idle timer
    startIdleTimer(); // Restart the idle timer
  };

  return (
    <Grid
      container
      spacing={0}
      direction="column"
      alignItems="center"
      justifyContent="center"
      style={{ minHeight: '100vh' }}
    >
      <Grid item xs={10} sm={8} md={6} lg={4}>
        <Card>
          <CardContent>
            <h2>Speech to Text Conversion</h2>

            <FormControl fullWidth variant="outlined" sx={{ marginBottom: 3 }}>
              <InputLabel id="languageSelectLabel">Select Language:</InputLabel>
              <Select
                labelId="languageSelectLabel"
                id="languageSelect"
                value={selectedLanguage}
                onChange={handleLanguageChange}
                label="Select Language"
              >
                {languages.map((language) => (
                  <MenuItem key={language.code} value={language.code}>
                    {language.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <Button
              variant="contained"
              onClick={isRecording ? stopRecording : startRecording}
              sx={{ backgroundColor: '#369', ':hover': { backgroundColor: '#258' } }}
              fullWidth
            >
              <BsFillMicFill size={20} /> {isRecording ? 'Stop Recording' : 'Start Recording'}
            </Button>

            <FormControl fullWidth>
              <TextField
                value={transcript}
                onChange={(e) => setTranscript(e.target.value)}
                placeholder="Generated text will appear here..."
                aria-label="Generated text"
                multiline
                rows={6}
                sx={{ marginBottom: 2, marginTop: 2 }}
              />

              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <CopyToClipboard text={transcript}>
                    <Button
                      variant="contained"
                      sx={{ backgroundColor: '#98c222' }}
                      onClick={handleCopy}
                      fullWidth
                    >
                      {copied ? 'Copied!' : 'Copy Text'}
                    </Button>
                  </CopyToClipboard>
                </Grid>
                <Grid item xs={6}>
                  <Button
                    variant="contained"
                    sx={{ backgroundColor: '#98c222' }}
                    onClick={clearText}
                    fullWidth
                  >
                    Clear Text
                  </Button>
                </Grid>
              </Grid>
            </FormControl>

            {audioUrl && (
              <Button
                variant="contained"
                color="success"
                onClick={handleDownload}
                sx={{ marginTop: 2 }}
                fullWidth
              >
                Download Processed Audio
              </Button>
            )}

            <audio ref={audioRef} controls style={{ display: 'none' }} />
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );
};

export default SpeechToText;
